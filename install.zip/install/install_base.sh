# 安装基础包

set -e

cd "$(dirname "${BASH_SOURCE[0]}")"

echo "update"
sudo apt-get update

echo "Install related base packages"
sudo apt-get install -y 
sudo apt-get install apt-utils
sudo apt-get install bash-completion
sudo apt-get install build-essential 
sudo apt-get install cmake 
sudo apt-get install libx11-dev 
sudo apt-get install software-properties-common

sudo apt-get install libboost-all-dev 
sudo apt-get install libeigen3-dev 
sudo apt-get install libgeographic-dev 
sudo apt-get install python3-catkin-tools 


echo "Install related ros packages"
sudo apt-get install ros-noetic-geometry-msgs
sudo apt-get install ros-noetic-visualization-msgs 
sudo apt-get install ros-noetic-nav-msgs 
sudo apt-get install ros-noetic-navigation*
sudo apt-get install ros-noetic-map-server


echo "All successfully"

