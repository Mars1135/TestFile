import launch
import launch_ros.actions

def generate_launch_description():
    ld = launch.LaunchDescription([
        launch.actions.DeclareLaunchArgument(
            name='town',
            default_value='Town03'
        ),
        launch_ros.actions.Node(
            package="map_visualizer",
            node_executable="osm_visualizer",
            node_name="osm_visualizer",
            output="screen",
            emulate_tty=True,
            parameters=[{
                "town": launch.substitutions.LaunchConfiguration('town'),
            }]
        )
    ])

    return ld