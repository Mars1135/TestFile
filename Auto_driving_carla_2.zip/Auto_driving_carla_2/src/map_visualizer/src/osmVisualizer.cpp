#include "../include/osmVisualizer/osmVisualizer.hpp"

OsmVisualizer::OsmVisualizer() : Node("OsmVisualizer")
{
  this->declare_parameter("town", "");
  this->declare_parameter("enable_inc_path_points", true);
  this->declare_parameter("interval", 2.0);
  if (!readParameters())
    rclcpp::shutdown();

  publisher_ = this->create_publisher<visualization_msgs::msg::MarkerArray>("/hd_map", 10);
  array_publisher_ = this->create_publisher<std_msgs::msg::Float64MultiArray>("/array", 10);
  timer_ = this->create_wall_timer(500ms, std::bind(&OsmVisualizer::timer_callback, this));

  std::string map_path = "/home/cg/Auto_driving_carla_2/src/map_visualizer/osms/" + town_name + ".osm";
  lanelet::LaneletMapPtr map = lanelet::load(map_path, lanelet::projection::UtmProjector(lanelet::Origin({0, 0})));

  for (auto point : map->pointLayer)
  {
    point.x() = point.attribute("local_x").asDouble().value();
    point.y() = point.attribute("local_y").asDouble().value();
  }

  fill_marker(map);
}

bool OsmVisualizer::readParameters()
{
  if (!this->get_parameter("town", town_name))
  {
    std::cout << "Failed to read parameter 'town' " << std::endl;
    return false;
  }
  if (!this->get_parameter("enable_inc_path_points", enable_inc_path_points_))
  {
    std::cout << "Failed to read parameter 'interval' to increase the path points" << std::endl;
    return false;
  }
  if (!this->get_parameter("interval", interval_))
  {
    std::cout << "Failed to read parameter 'interval' to increase the path points" << std::endl;
    return false;
  }
  return true;
}

void OsmVisualizer::timer_callback()
{
  // publisher_->get_subscription_count() > 0 && m_marker_array.markers.size() > 0
  // if( publisher_->get_subscription_count() > 0)
  {
    publisher_->publish(m_marker_array);
    array_publisher_->publish(m_array);
  }
}

void OsmVisualizer::fill_marker(lanelet::LaneletMapPtr &t_map)
{
  size_t i = 0;

  // for lanelets
  for (const auto &ll : t_map->laneletLayer)
  {
    std::vector<lanelet::ConstLineString3d> bounds;
    bounds.push_back(ll.leftBound());
    bounds.push_back(ll.rightBound());

    for (const auto &bound : bounds)
    {
      visualization_msgs::msg::Marker marker;
      marker.header.frame_id = "map";
      marker.header.stamp = rclcpp::Clock{}.now();
      marker.ns = "lanelet";
      marker.id = i;
      i++;
      marker.type = visualization_msgs::msg::Marker::LINE_STRIP;
      marker.action = visualization_msgs::msg::Marker::ADD;
      marker.scale.x = 0.1;
      marker.color.a = 1.0;
      marker.color.r = 232;
      marker.color.g = 44;
      marker.color.b = 44;
      for (const auto &point : bound)
      {
        geometry_msgs::msg::Point p;
        p.x = point.x();
        p.y = point.y();
        p.z = 0;
        marker.points.push_back(p);
      }
      m_marker_array.markers.push_back(marker);
    }
  }
}