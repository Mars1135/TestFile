#include <chrono>
#include <string>
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include "geometry_msgs/msg/vector3.hpp"
#include <chrono>
#include <visualization_msgs/msg/marker.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include <tf2_ros/transform_broadcaster.h>
#include <eigen3/Eigen/Dense>

using namespace std::chrono_literals;

visualization_msgs::msg::Marker car_marker;
double speed, steer;
double wheel_base = 2.7; // 轴距（前后轮之车轮轴距离）
double start_x, start_y, start_theta;

double getYaw(const geometry_msgs::msg::Quaternion &q)
{
    return atan2(2.0 * (q.z * q.w + q.x * q.y), -1.0 + 2.0 * (q.w * q.w + q.x * q.x));
}

geometry_msgs::msg::Quaternion yawToQuaternionMsg(const double &yaw)
{
    geometry_msgs::msg::Quaternion msg;
    Eigen::Quaterniond q =
        Eigen::AngleAxisd(0, Eigen::Vector3d::UnitX()) * Eigen::AngleAxisd(0, Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(yaw, Eigen::Vector3d::UnitZ());
    msg.w = q.w();
    msg.x = q.x();
    msg.y = q.y();
    msg.z = q.z();
    return msg;
}

void control_data(const geometry_msgs::msg::Vector3::SharedPtr msg)
{
    speed = msg->x;
    steer = msg->y;
}

void car_start(const geometry_msgs::msg::Vector3::SharedPtr msg)
{
    start_x = msg->x;
    start_y = msg->y;
    // std::cout << "x:" << start_x << "\n";
    // std::cout << "y:" << start_y << "\n";
    start_theta = msg->z;
    speed = 0;
    steer = start_theta;
}

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    auto node = rclcpp::Node::make_shared("car_simulation");

    auto odom_publish = node->create_publisher<nav_msgs::msg::Odometry>("/xsj/odom", 10);
    auto car_publish = node->create_publisher<visualization_msgs::msg::Marker>("/xsj/car/car_state", 10);

    std::unique_ptr<tf2_ros::TransformBroadcaster> odom_broadcaster = std::make_unique<tf2_ros::TransformBroadcaster>(node);

    auto sub = node->create_subscription<geometry_msgs::msg::Vector3>("/xsj/car/control_car", 10, control_data);            // 订阅控制信息
    auto car_start_pose = node->create_subscription<geometry_msgs::msg::Vector3>("/xsj/car/car_start_pose", 10, car_start); // 订阅起点信息

    rclcpp::Clock steady_clock_{RCL_STEADY_TIME};

    auto cur_time = steady_clock_.now();
    auto last_time = steady_clock_.now();

    rclcpp::WallRate loop_rate(100ms);

    while (rclcpp::ok())
    {
        cur_time = steady_clock_.now();

        double Length = 4.4; // 车长
        double width = 1.8;  // 车宽
        car_marker.pose.orientation = yawToQuaternionMsg(start_theta);
        car_marker.header.frame_id = "map";
        car_marker.header.stamp = builtin_interfaces::msg::Time(node->now());
        car_marker.ns = "basic_shapes";
        car_marker.id = 0; // 注意了
        car_marker.type = visualization_msgs::msg::Marker::ARROW;
        car_marker.action = visualization_msgs::msg::Marker::ADD;
        car_marker.pose.position.x = start_x;
        car_marker.pose.position.y = start_y;
        car_marker.pose.position.z = 0;
        car_marker.scale.x = Length;
        car_marker.scale.y = width;
        car_marker.scale.z = 1.0;
        car_marker.color.r = 1.0f;
        car_marker.color.g = 1.0f;
        car_marker.color.b = 0.0f;
        car_marker.color.a = 1.0;
        car_publish->publish(car_marker);

        double dt = (cur_time - last_time).seconds();
        double delta_x = speed * cos(start_theta) * dt;
        double delta_y = speed * sin(start_theta) * dt;
        double delta_theta = (speed * tan(steer) / wheel_base) * dt;
        // RCLCPP_WARN(node->get_logger(), "dt: %2f", dt);

        start_x += delta_x;
        start_y += delta_y;
        start_theta += delta_theta;

        geometry_msgs::msg::Quaternion odom_quat = yawToQuaternionMsg(start_theta);

        // 加载vehicle_description车辆模型才用
        // geometry_msgs::msg::TransformStamped odom_trans;
        // odom_trans.header.stamp = cur_time;
        // odom_trans.header.frame_id = "map";
        // odom_trans.child_frame_id = "odom";
        // odom_trans.transform.translation.x = start_x;
        // odom_trans.transform.translation.y = start_y;
        // odom_trans.transform.translation.z = 0.0;
        // odom_trans.transform.rotation = odom_quat;
        // odom_broadcaster->sendTransform(odom_trans);

        // 填充里程计数据
        nav_msgs::msg::Odometry odom;
        odom.header.frame_id = "map";
        odom.header.stamp = cur_time;
        // 位置信息
        odom.pose.pose.position.x = start_x;
        odom.pose.pose.position.y = start_y;
        odom.pose.pose.orientation = odom_quat;
        // 发布里程计
        odom_publish->publish(odom);
        last_time = cur_time;

        rclcpp::spin_some(node);
        loop_rate.sleep();
    }
    rclcpp::shutdown();
    return 0;
}