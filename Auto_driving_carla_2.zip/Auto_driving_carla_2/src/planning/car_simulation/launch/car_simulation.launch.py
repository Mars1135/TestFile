import os
import launch
from launch import LaunchDescription
import launch_ros.actions
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():

    start_car_simulation_cmd = launch_ros.actions.Node(package='car_simulation', node_executable='car_model_node',  output='screen')
                                
    ld = LaunchDescription()
    ld.add_action(start_car_simulation_cmd)
    return ld

if __name__ == '__main__':
    generate_launch_description()
