#ifndef __GLOBAL_ROUTING_H
#define __GLOBAL_ROUTING_H

#include <iostream>
#include <boost/thread.hpp>
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/pose_array.hpp>
#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include "geometry_msgs/msg/vector3.hpp"
#include <visualization_msgs/msg/marker.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include "global_path_struct.h"
#include "ReferenceLine_Split.h"
#include "lqr_controller.h"
#include "controller.h"
#include "carla_msgs/msg/carla_ego_vehicle_control.hpp"
#include <tf2/utils.h>

#include "waypoint_msgs/msg/waypoint.hpp"
#include "waypoint_msgs/msg/waypoint_array.hpp"

using namespace std;
using namespace carla_pnc;
using namespace std::chrono_literals;
using std::placeholders::_1;
static const rclcpp::Logger LOGGER = rclcpp::get_logger("global_routing_node");

class GlobalRouting : public rclcpp::Node
{
public:
  GlobalRouting();
  ~GlobalRouting();
  bool init();
  void thread_routing(void);

  void odom_call_back(const nav_msgs::msg::Odometry::SharedPtr msg);
  void start_pose_call_back(const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg);
  void goal_pose_call_back(const geometry_msgs::msg::PoseStamped::SharedPtr msg);

  void get_Waypoints_From_Carla(const nav_msgs::msg::Path::SharedPtr waypoints);

  void Vehival_Theta(const geometry_msgs::msg::PoseArray::SharedPtr theta);
  void Vehival_Kappa(const geometry_msgs::msg::PoseArray::SharedPtr kappa);
  void Vehival_Traj(const waypoint_msgs::msg::WaypointArray::SharedPtr msg);
  void Vehival_Go(const std_msgs::msg::String::SharedPtr go);
  bool Vehical_Stop(const geometry_msgs::msg::Pose &goal_point, nav_msgs::msg::Odometry &odom);

  bool Size_Can();
  void create_map();
  void publish_car_start_pose(const geometry_msgs::msg::Pose &start_pose);
  void CreateLqrOffline(const Eigen::MatrixXd &Q, const Eigen::MatrixXd &R);
  Eigen::MatrixXd calc_dlqr(double vx, const Eigen::MatrixXd &Q, const Eigen::MatrixXd &R);
  
  /***********************************整车参数**************************************/
  double L = 3.0;                                                         // 轴距
  double cf = -155494.663;                                                // 前轮侧偏刚度,左右轮之和
  double cr = -155494.663;                                                // 后轮侧偏刚度, 左右轮之和
  double mass_fl = 1845.0 / 4;                                            // 左前悬的质量
  double mass_fr = 1845.0 / 4;                                            // 右前悬的质量
  double mass_rl = 1845.0 / 4;                                            // 左后悬的质量
  double mass_rr = 1845.0 / 4;                                            // 右后悬的质量
  double mass_front = mass_fl + mass_fr;                                  // 前悬质量
  double mass_rear = mass_rl + mass_rr;                                   // 后悬质量
  double mass = mass_front + mass_rear;                                   // 车辆载荷
  double lf = L * (1.0 - mass_front / mass);                              // 汽车前轮到中心点的距离
  double lr = L * (1.0 - mass_rear / mass);                               // 汽车后轮到中心点的距离
  double Iz = std::pow(lf, 2) * mass_front + std::pow(lr, 2) * mass_rear; // 车辆绕z轴转动的转动惯量

protected:
  std::vector<Eigen::MatrixXd> lqr_k_table;           // LQR离线求解后的k
  double k_pure;                                      // PurePursuit"增益系数
  double k_cte;                                       // Stanley"增益系数
  double Q_ed, Q_ed_dot, Q_ephi, Q_ephi_dot, R_value; // LQR_dynamics Q  R矩阵权重
  double Q_ex_k, Q_ed_k, Q_ephi_k, R_value_k;         // LQR_kinematics Q  R矩阵权重
  double kp, ki, kd;                                  // 纵向PID

private:
  Eigen::MatrixXd hdmap_way_points;           // 中心点坐标
  std::vector<double> speeds, thetas, kappas; // 获取局部规划的速度与航向角,曲率
  nav_msgs::msg::Odometry car_odom_;
  std::vector<car_state> local_waypoints;     // 局部规划路径点
  car_state cur_pose; // 车辆当前状态
  
  // 函数对象
  geometry_msgs::msg::Vector3 msg_ros; // 发布控制数据
  visualization_msgs::msg::MarkerArray obstacle_points, map_points;
  nav_msgs::msg::Path referenceline_points;

  // 控制算法
  LqrController Lqr;

  // 路径点
  nav_msgs::msg::Path dynamic_points;
  Eigen::MatrixXd hdmap_way_points_;

  // 点
  geometry_msgs::msg::Pose start_pose_;
  geometry_msgs::msg::Pose goal_pose_;

  // carla
  rclcpp::Publisher<carla_msgs::msg::CarlaEgoVehicleControl>::SharedPtr carla_control_cmd_pub_; // 发布carla控制命令
  rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr carla_waypoints_sub_;
  rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr goal_point_pub_;

  // visual Pub
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr obstacle_points_pub_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr map_points_pub_;
  rclcpp::Publisher<geometry_msgs::msg::Vector3>::SharedPtr control_data_pub_;
  rclcpp::Publisher<geometry_msgs::msg::Vector3>::SharedPtr vehicle_start_pose_pub_;
  rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr referenceline_pub_;

  // visual Subscriber
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr start_pose_subscriber_;
  rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr goal_pose_subscriber_;
  rclcpp::Subscription<geometry_msgs::msg::PoseArray>::SharedPtr vehival_theta;
  rclcpp::Subscription<geometry_msgs::msg::PoseArray>::SharedPtr vehival_kappa;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr vehival_go;
  rclcpp::Subscription<waypoint_msgs::msg::WaypointArray>::SharedPtr vehival_traj;

  // thread
  boost::thread *routing_thread_;

  // flag
  bool carla_simulation;
  string role_name, control_method;
  bool is_begin_reference;  // 控制参考线发布一次
  int obstacle_id;          // 手动标注障碍物位置坐标显示
  double car_speed;         // 车速度
  double goal_distanse;     // 车速度
  bool is_vehical_stop_set; // 判断车是否要停下来
  bool is_start_pose_set;   // 是否定义了起点
  bool is_goal_pose_set;    // 是否定义了终点
  int use_what_planner;     // 规划算法
  int use_what_controller;  // 控制算法
  bool which_smoothers;     // 选择参考线平滑方式
  string Start_dynamic;     // 判断局部规划是否开始
};

#endif