#ifndef REFERENCELINE_SPLIT_H
#define REFERENCELINE_SPLIT_H

#include "rclcpp/rclcpp.hpp"
#include "nav_msgs/msg/path.hpp"
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Eigen>
#include <eigen3/Eigen/Dense>
#include <iostream>
#include <fstream>
#include <string>
#include "global_path_struct.h"
#include "cos_theta_smoother.h"
#include "fem_pos_deviation_smoother.h"

class ReferenceLine_Split
{
public:
  ReferenceLine_Split() = default;
  ReferenceLine_Split(bool which_smoother);
  ~ReferenceLine_Split() = default;
  nav_msgs::msg::Path referenceLine_split(Eigen::MatrixXd &hdmap_way_points);
  void Publish(Eigen::MatrixXd &path_point_after_interpolation_, nav_msgs::msg::Path &referenceline);
  void NormalizePoints(std::vector<std::pair<double, double>> *xy_points);
  void DeNormalizePoints(std::vector<std::pair<double, double>> *xy_points);
  void average_interpolation(Eigen::MatrixXd &input, Eigen::MatrixXd &output, double interval_dis,
                             double distance);

private:
  Eigen::MatrixXd path_point_after_interpolation;
  Eigen::MatrixXd way_point, rest_point;
  bool which_smoothers;
  double zero_x_ = 0.0;
  double zero_y_ = 0.0;
};

#endif // REFERENCELINE_SPLIT_H