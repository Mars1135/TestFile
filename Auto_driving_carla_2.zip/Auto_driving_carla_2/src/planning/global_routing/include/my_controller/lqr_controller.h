#pragma once

#define EPS 1.0e-4
#define MY_PI 3.1415926

#include <eigen3/Eigen/Dense>
#include <vector>
#include <iostream>
#include <tf2/utils.h>
#include "nav_msgs/msg/odometry.hpp"
#include "nav_msgs/msg/path.hpp"

using namespace std;
using namespace Eigen;

class LqrController
{
public:
  LqrController() = default;
  ~LqrController() = default;

  MatrixXd calRicatti(MatrixXd A, MatrixXd B, MatrixXd Q, MatrixXd R);
  double normalizeAngle(double angle);

  void lqr_control(const nav_msgs::msg::Odometry &robot_state,const nav_msgs::msg::Path &trj_point,
                   const vector<double> trj_k, const vector<double> trj_t, const vector<double> trj_v,
                   double &out_turn_agl, int &out_index);
};


