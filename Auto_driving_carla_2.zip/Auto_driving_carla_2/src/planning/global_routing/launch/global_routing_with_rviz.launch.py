import os
import launch
from launch import LaunchDescription
import launch_ros.actions
from ament_index_python.packages import get_package_share_directory

# 需要修改
rviz_filepath = "/home/cg/Auto_driving_carla_2/src/planning/global_routing/config/planning.rviz"
assert os.path.exists(rviz_filepath)


def generate_launch_description():

    start_global_routing_cmd = launch.actions.IncludeLaunchDescription(
        launch.launch_description_sources.PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory(
                'global_routing'), 'global_routing.launch.py')
        ),
        launch_arguments={
        }.items()
    )
    start_car_simulation_cmd = launch.actions.IncludeLaunchDescription(
        launch.launch_description_sources.PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory(
                'car_simulation'), 'car_simulation.launch.py')
        ),
        launch_arguments={
        }.items()
    )

    start_rviz_cmd = launch_ros.actions.Node(package='rviz2', node_executable='rviz2', node_name='rviz2', output='screen', parameters=[{'use_sim_time': True}],
                                             arguments=['-d', rviz_filepath])

    ld = LaunchDescription()
    ld.add_action(start_global_routing_cmd)
    ld.add_action(start_car_simulation_cmd)
    ld.add_action(start_rviz_cmd)
    return ld


if __name__ == '__main__':
    generate_launch_description()
