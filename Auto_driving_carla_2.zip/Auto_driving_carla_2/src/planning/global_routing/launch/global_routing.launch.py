import os
import launch
from launch import LaunchDescription
import launch_ros.actions
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    ld = launch.LaunchDescription([
        launch.actions.DeclareLaunchArgument(
            name='carla',
            default_value='true'
        ),
        launch.actions.DeclareLaunchArgument(
            name='ego_vehicle_name',
            default_value='ego_vehicle'
        ),
        launch.actions.DeclareLaunchArgument(
            name='control',  # lqr，只有lqr
            default_value='2' # 不能改
        ),
        #1是纯frenet规划
        # 2是lattice规划
        launch.actions.DeclareLaunchArgument(
            name='planner', # 只有lattice和frenet
            default_value='2' #  
        ),
        launch.actions.DeclareLaunchArgument(
            name='use_lateral_optimization',
            default_value='false'
        ),
        launch.actions.DeclareLaunchArgument(
            name='which_smoother',
            default_value='false'
        ),
        launch.actions.DeclareLaunchArgument(
            name='goal_dis',
            default_value='2.0'
        )
    ])

    start_global_routing_cmd = launch_ros.actions.Node(
        package='global_routing',
        node_executable='global_routing_node',
        output='screen',
        parameters=[{
                        'carla_simulation': launch.substitutions.LaunchConfiguration('carla'),
                        'role_name': launch.substitutions.LaunchConfiguration('ego_vehicle_name'),
                        'use_what_controller': launch.substitutions.LaunchConfiguration('control'),
                        'use_what_planner': launch.substitutions.LaunchConfiguration('planner'),
                        'which_smoothers': launch.substitutions.LaunchConfiguration('which_smoother'),
                        'goal_distanse': launch.substitutions.LaunchConfiguration('goal_dis')
        }]
    )

    start_dynamic_routing_cmd = launch.actions.IncludeLaunchDescription(
        launch.launch_description_sources.PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory(
                'dynamic_routing'), 'dynamic_routing.launch.py')
        ),
        launch_arguments={
            'is_planner': launch.substitutions.LaunchConfiguration('planner'),
            'is_lateral_optimization': launch.substitutions.LaunchConfiguration('use_lateral_optimization'),
            'is_carla_simulation': launch.substitutions.LaunchConfiguration('carla'),
            'ego_vehicle_name': launch.substitutions.LaunchConfiguration('ego_vehicle_name'),
            'is_goal': launch.substitutions.LaunchConfiguration('goal_dis')        
            }.items()
    )

    ld.add_action(start_global_routing_cmd)
    ld.add_action(start_dynamic_routing_cmd)

    return ld


if __name__ == '__main__':
    generate_launch_description()
