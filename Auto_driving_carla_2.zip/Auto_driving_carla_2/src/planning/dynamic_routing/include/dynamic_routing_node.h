#ifndef LATTICE_DYNAMIC_ROUTING_H
#define LATTICE_DYNAMIC_ROUTING_H

#include <iostream>
#include <boost/thread.hpp>
#include "rclcpp/rclcpp.hpp"
#include "CubicSpline2D.h"
#include "lattice_planner.h"
#include "PlanningTarget.h"
#include "std_msgs/msg/float64.hpp"
#include "std_msgs/msg/string.hpp"
#include <string>
#include <vector>
#include "FrenetOptimalTrajectory.h"
#include "reference_line.h"
#include <nav_msgs/msg/occupancy_grid.hpp>
#include "Obstacle_test_node.h"
#include "waypoint_msgs/msg/waypoint.hpp"
#include "waypoint_msgs/msg/waypoint_array.hpp"
#include "waypoint_msgs/msg/waypoint_array.hpp"
#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>

using namespace std;
using namespace std::chrono_literals;
using std::placeholders::_1;
static const rclcpp::Logger LOGGER = rclcpp::get_logger("dynamic_routing_node");

class Dynamic_routing : public rclcpp::Node
{
public:
  Dynamic_routing();
  ~Dynamic_routing();
  bool init();
  void thread_routing(void);

  void odom_call_back(const nav_msgs::msg::Odometry::SharedPtr odom);
  void start_pose_call_back(const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg);
  void goal_pose_call_back(const geometry_msgs::msg::PoseStamped::SharedPtr msg);
  void path_pose_call_back(const nav_msgs::msg::Path::SharedPtr msg);

  bool is_update_dynamic(nav_msgs::msg::Path &trj_point_array, nav_msgs::msg::Odometry &odom, int size);
  bool is_collision(FrenetPath *fts, double COLLISION_CHECK);
  void publish_vehical_start_pose(const geometry_msgs::msg::Pose &start_pose);

private:
  int use_what_planner; // 选择规划方案
  double goal_distanse;
  double COLLISION_CHECK_THRESHOLD;
  double MaxT;
  double MinT;
  bool has_stop = false;           // 是否需要停车,先默认不需要
  bool FLAGS_lateral_optimization; // 选择二次规划
  bool set_reference;              // 判断参考线已经回调
  bool ego_is_running;
  std::string yaml_filepath;

  // ROS
  // visual publish
  rclcpp::Publisher<waypoint_msgs::msg::WaypointArray>::SharedPtr waypoints_pub_;
  rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr waypoints_vis_pub_;
  rclcpp::Publisher<geometry_msgs::msg::PoseArray>::SharedPtr local_paths_a;
  rclcpp::Publisher<geometry_msgs::msg::PoseArray>::SharedPtr local_paths_t;
  rclcpp::Publisher<geometry_msgs::msg::PoseArray>::SharedPtr local_paths_k;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr Start_Dynamic;

  // visual sub
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr start_pose_subscriber_;
  rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr goal_pose_subscriber_;
  rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr path_pose_subscriber_;
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr subMap_subscriber_;

  // visualmsgs
  visualization_msgs::msg::MarkerArray ObstacleArray;
  visualization_msgs::msg::Marker marker;
  geometry_msgs::msg::PoseArray pubLocalPath_a;
  geometry_msgs::msg::PoseArray pubLocalPath_s;
  geometry_msgs::msg::PoseArray pubLocalPath_t;
  geometry_msgs::msg::PoseArray pubLocalPath_k;
  nav_msgs::msg::Path reference_lines;

  // 变量
  nav_msgs::msg::Path traj_points_; // 局部规划的轨迹,nav_msgs类型
  double d0;                        // 初始的横向偏移值 [m]
  double dd0;                       // 初始的横向速度 [m/s]
  double ddd0;                      // 初始的横向加速度 [m/s^2]
  double init_lon_state;            // 初始的纵向值[m]
  double ds0;                       // 初始的纵向速度[m/s]
  double dds0;                      // 初始的纵向加速度[m/ss]
  double init_relative_time;        // 规划起始点的时间
  double x_init;
  double y_init;
  double z_init;
  double v_init;
  double a_init;
  double theta_init;
  double theta_end;
  double kappa_init;
  double dkappa_init;

  std_msgs::msg::String start_dynamic; // 判断局部规划是否开始
  DiscretizedTrajectory best_path;     // 最佳路径
  FrenetPath *best_frenet_path;        // 最佳路径,要析构
  CubicSpline2D *csp;                  // 样条插值函数

  // thread
  boost::thread *routing_thread_;
  // 对象
  LatticePlanner LP;
};

#endif
