#ifndef OBSTACLE_TEST_H
#define OBSTACLE_TEST_H

#include <boost/thread.hpp>
#include "rclcpp/rclcpp.hpp"
#include <string>
#include <vector>
#include <fstream>
#include <eigen3/Eigen/Dense>
#include <boost/thread.hpp>
#include "Obstacle.h"
#include "object_msgs/msg/dynamic_object_array.hpp"
#include "object_msgs/msg/semantic.hpp"
#include "object_msgs/msg/shape.hpp"
#include "object_msgs/msg/state.hpp"
#include <visualization_msgs/msg/marker.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include "ObjectDecision.h"

using namespace Eigen;
using namespace std;
using namespace std::chrono_literals;
using std::placeholders::_1;

class ObstacleTest : public rclcpp::Node 
{
public:
  ObstacleTest(const std::string &node_name_, const std::string &obstacle_test_path_);
  ObstacleTest() = default;
  ~ObstacleTest()= default;
  void Publish_StaticObstacle();

  void Publish_DynamicObstacle(double x_pose_covariance, double y_pose_covariance, double head,
                               double x_pose_covariance1, double y_pose_covariance1, double head1);
  void thread_obstacle_test(void);
  void thread_obstacle_visualization(void);

  void caculate_points(std::string obstacle_path, std::vector<double> &sample_x,
                       std::vector<double> &sample_y, std::vector<double> &sample_h);
  void Turn_obstacles_into_squares(visualization_msgs::msg::Marker &marker,
                                   const object_msgs::msg::DynamicObject Primitive_obstacle, const int id);
  void visualization(object_msgs::msg::DynamicObjectArray Obstacles);

private:
  // thread
  boost::thread *routing_thread_obstacle_test;
  boost::thread *routing_thread_obstacle;

  rclcpp::Publisher<object_msgs::msg::DynamicObjectArray>::SharedPtr Pub_Obstacles;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr Obstacle_Visualization;
  std::string obstacle_test_path;
  object_msgs::msg::DynamicObjectArray Objects;
  Obstacle_avoid oba;
};

#endif // OBSTACLE_TEST_H
