#include "Ob_prediction_trajectory.h"

namespace prediction
{
    Ob_Trajectory::Ob_Trajectory()
    {
        trajectory_points = {};
    }
} // namespace prediction
