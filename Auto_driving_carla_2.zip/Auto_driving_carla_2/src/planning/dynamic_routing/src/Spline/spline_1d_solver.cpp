#include "spline_1d_solver.h"
/*
暴富
*/