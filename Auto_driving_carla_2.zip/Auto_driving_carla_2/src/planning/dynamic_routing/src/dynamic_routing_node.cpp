#include "dynamic_routing_node.h"

// 全局变量
std::vector<Obstacle> AllObstacle;                        // 感知一帧识别到的所有障碍物
std::pair<vector<double>, vector<double>> reference_path; // 参考路径点位置（x,y）
geometry_msgs::msg::Pose start_pose_;                     // 起点
geometry_msgs::msg::Pose goal_pose_;                      // 终点
nav_msgs::msg::Odometry sub_odom_;                        // odom
bool messege1;                                            // 控制发布一次的变量
bool messege2;                                            // 控制发布一次的变量
double init_lon_state;                                    // 初始弧长
std::vector<double> accumulated_s;                        // 本参考线纵向距离
std::vector<ReferencePoint> reference_points;             // 本参考线参考路径点参数
std::vector<double> accumulated_s_other;                  // 另外一条参考线纵向距离
std::string obstacle_test_path;
bool carla_simulation;
std::string role_name;

//---------------------------------默认构造函数：规划函数,初始化参数---------------------------------//
Dynamic_routing::Dynamic_routing() : Node("dynamic_routing_node")
{
  // 参数获取
  this->declare_parameter<int>("use_what_planner", use_what_planner);
  this->declare_parameter<bool>("carla_simulation", carla_simulation);
  this->declare_parameter<bool>("use_lateral_optimization", FLAGS_lateral_optimization);
  this->declare_parameter<double>("COLLISION_CHECK_THRESHOLD", COLLISION_CHECK_THRESHOLD);
  this->declare_parameter<double>("MaxT", MaxT);
  this->declare_parameter<double>("MinT", MinT);
  this->declare_parameter<double>("goal_distanse", goal_distanse);
  this->declare_parameter<std::string>("role_name", role_name);
  this->declare_parameter<std::string>("obstacle_test_path", obstacle_test_path);

  this->get_parameter<int>("use_what_planner", use_what_planner);
  this->get_parameter<bool>("carla_simulation", carla_simulation);
  this->get_parameter<bool>("use_lateral_optimization", FLAGS_lateral_optimization);
  this->get_parameter<double>("COLLISION_CHECK_THRESHOLD", COLLISION_CHECK_THRESHOLD);
  this->get_parameter<double>("MaxT", MaxT);
  this->get_parameter<double>("MinT", MinT);
  this->get_parameter<double>("goal_distanse", goal_distanse);
  this->get_parameter<std::string>("role_name", role_name);
  this->get_parameter<std::string>("obstacle_test_path", obstacle_test_path);

  RCLCPP_WARN(this->get_logger(), obstacle_test_path);
  RCLCPP_WARN(this->get_logger(), "goal_distanse:%f", goal_distanse);

  ////////////////////////////////发布////////////////////////////////////////
  waypoints_vis_pub_ = this->create_publisher<nav_msgs::msg::Path>("/xsj/planning/dynamic_waypoints_vis", 10);       // 发布局部轨迹
  waypoints_pub_ = this->create_publisher<waypoint_msgs::msg::WaypointArray>("/xsj/planning/dynamic_waypoints", 10); // 发布局部轨迹
  local_paths_a = this->create_publisher<geometry_msgs::msg::PoseArray>("/xsj/planning/dynamic_paths_a", 10);        // 发布局部轨迹的加速度
  local_paths_t = this->create_publisher<geometry_msgs::msg::PoseArray>("/xsj/planning/dynamic_paths_t", 10);        // 发布局部轨迹的航向角
  local_paths_k = this->create_publisher<geometry_msgs::msg::PoseArray>("/xsj/planning/dynamic_paths_k", 10);        // 发布局部轨迹的曲率
  Start_Dynamic = this->create_publisher<std_msgs::msg::String>("/xsj/planning/Start_Dynamic", 10);                  // 发布局部轨迹成功生存的信号

  ///////////////////////////////订阅////////////////////////////////////////
  start_pose_subscriber_ = this->create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>("/initialpose", 8,
                                                                                                    std::bind(&Dynamic_routing::start_pose_call_back, this, std::placeholders::_1));
  goal_pose_subscriber_ = this->create_subscription<geometry_msgs::msg::PoseStamped>("/goal_pose", 8,
                                                                                     std::bind(&Dynamic_routing::goal_pose_call_back, this, std::placeholders::_1));
  path_pose_subscriber_ = this->create_subscription<nav_msgs::msg::Path>("/xsj/reference/referenceLine_centerPoint", 8,
                                                                         std::bind(&Dynamic_routing::path_pose_call_back, this, std::placeholders::_1));

  if (carla_simulation == false)
  {
    odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>("/xsj/odom", 8,
                                                                   std::bind(&Dynamic_routing::odom_call_back, this, std::placeholders::_1));
  }
  else
  {
    odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>("/carla/" + role_name + "/odometry", 8,
                                                                   std::bind(&Dynamic_routing::odom_call_back, this, std::placeholders::_1));
  }

  sleep(2);
  // 打印规划器
  if (use_what_planner == 1)
    RCLCPP_WARN(this->get_logger(), "Planner: frenet based");
  else if (use_what_planner == 2 && FLAGS_lateral_optimization == false)
    RCLCPP_WARN(this->get_logger(), "Planner: lattice based sample");
  else if (use_what_planner == 2 && FLAGS_lateral_optimization == true)
    RCLCPP_WARN(this->get_logger(), "Planner: lattice based optimization");

  // 参数初始化
  ego_is_running = false;
  set_reference = false;

  string aa = "0";
  start_dynamic.data = aa.c_str();
  Start_Dynamic->publish(start_dynamic);

  routing_thread_ = new boost::thread(boost::bind(&Dynamic_routing::thread_routing, this));

  RCLCPP_WARN(this->get_logger(), "Finish DynamicRouting Node!");
}

Dynamic_routing::~Dynamic_routing(void)
{
  delete routing_thread_;
  delete best_frenet_path;
  delete csp;
}

//-------------------------------------------回调函数---------------------------------------------//
/*定义起点位置*/
void Dynamic_routing::start_pose_call_back(const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg)
{
  if (ego_is_running == false)
  {
    // -------------------------路径规划参数在定义终点的时候初始化--------------------------//
    d0 = 0;                           // 初始的横向偏移值 [m]
    dd0 = 0;                          // 初始的横向速度 [m/s]
    ddd0 = 0;                         // 初始的横向加速度 [m/s^2]
    init_lon_state = 0;               // 初始的纵向值[m]
    ds0 = Config_.default_init_speed; // 初始的纵向速度[m/s]
    dds0 = 0;                         // 初始的纵向加速度[m/ss]
    init_relative_time = 0;           // 规划起始点的时间
    v_init = ds0;                     // 规划起始点的速度，没有横向速度，直接等于ds0
    a_init = 0;                       // 规划起始点的加速度
    z_init = 0;
    messege1 = false;

    start_pose_.position.x = msg->pose.pose.position.x;
    start_pose_.position.y = msg->pose.pose.position.y;
    start_pose_.orientation = msg->pose.pose.orientation;
    x_init = start_pose_.position.x;
    y_init = start_pose_.position.y;
    theta_init = tf2::getYaw(msg->pose.pose.orientation); // 初始朝向
  }
}

/*定义终点位置*/
void Dynamic_routing::goal_pose_call_back(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
{
  goal_pose_.position.x = msg->pose.position.x;
  goal_pose_.position.y = msg->pose.position.y;
  theta_end = tf2::getYaw(msg->pose.orientation);
}

/*订阅获取地图坐标*/
void Dynamic_routing::path_pose_call_back(const nav_msgs::msg::Path::SharedPtr msg)
{
  reference_path.first.clear();
  reference_path.second.clear();
  accumulated_s.clear();
  reference_points.clear();
  if (msg->poses.size() > 0)
  {
    std::vector<double> headings;
    std::vector<double> kappas;
    std::vector<double> dkappas;
    std::vector<std::pair<double, double>> xy_points;

    // auto beforeTime = std::chrono::steady_clock::now(); //计时开始
    for (size_t i = 0; i < msg->poses.size(); i++)
    {
      reference_path.first.push_back(msg->poses[i].pose.position.x);
      reference_path.second.push_back(msg->poses[i].pose.position.y);
      std::pair<double, double> xy;
      xy.first = msg->poses[i].pose.position.x;
      xy.second = msg->poses[i].pose.position.y;
      xy_points.push_back(xy);
    }
    // 这个过程需要消耗时间
    if (!PathMatcher::ComputePathProfile(xy_points, &headings, &accumulated_s, &kappas, &dkappas))
    {
      RCLCPP_WARN(this->get_logger(), "rerferenceline generate failed!");
    }
    else
    {
      for (size_t i = 0; i < xy_points.size(); i++)
      {
        // 创建ReferencePoint类
        ReferencePoint reference_point(kappas[i], dkappas[i], xy_points[i].first, xy_points[i].second, headings[i],
                                       accumulated_s[i]);
        reference_points.emplace_back(reference_point);
      }
      RCLCPP_WARN(this->get_logger(), "dynamic's rerferenceline generate successfully!");
    }
    // 参考线三次样条方程
    // 输入(x1,y1),(x2,y2)......(xn,yn),返回 x-s坐标系与y-s坐标系
    csp = new CubicSpline2D(reference_path.first, reference_path.second, accumulated_s); // 只需要执行一次
    // 初始化
    kappa_init = kappas.front();
    dkappa_init = dkappas.front();
    init_lon_state = 0; // 复位
  }
  set_reference = true;
}

/*读回ros odom坐标系数据 , 接收车的里程信息，控制车的移动*/
void Dynamic_routing::odom_call_back(const nav_msgs::msg::Odometry::SharedPtr odom)
{
  sub_odom_ = *odom; // 车的里程信息，就是位置信息
  // std::cout << "car_odom_x:" << sub_odom_.pose.pose.position.x << "\n";
  // std::cout << "car_odom_y:" << sub_odom_.pose.pose.position.y << "\n";
  // std::cout << "car_odom_z:" << sub_odom_.pose.pose.position.z << "\n";
  // std::cout << "----------------------------------"
  //           << "\n";
}

//------------------------------------------子函数---------------------------------------------//
// 判断车是否走完轨迹的设置距离，是的话再发给局部规划，在车目前的位置之前更新局部规划轨迹
bool Dynamic_routing::is_update_dynamic(nav_msgs::msg::Path &trj_point_array, nav_msgs::msg::Odometry &odom, int size)
{
  double distance = sqrt(pow(odom.pose.pose.position.x - trj_point_array.poses[size].pose.position.x, 2) +
                         pow(odom.pose.pose.position.y - trj_point_array.poses[size].pose.position.y, 2));
  if (distance < 1) // 接近了
  {
    return true;
  }
  return false;
}

// 在frenet规划中，检查路径是否与障碍物碰撞,没有撞,返回false.撞了返回true （lattice规划用不到）
bool Dynamic_routing::is_collision(FrenetPath *fts, double COLLISION_CHECK)
{
  // 虚拟障碍物的避障
  for (size_t i = 0; i < AllObstacle.size(); i++) // 遍历障碍物
  {
    for (size_t j = 0; j < fts->x.size() - 1; j++) // 后半部分的点
    {
      double llx = AllObstacle[i].centerpoint.position.x;
      double lly = AllObstacle[i].centerpoint.position.y;
      double xx = llx - fts->x[j];
      double yy = lly - fts->y[j];
      double x2 = xx * xx;
      double y2 = yy * yy;
      double closest1 = sqrt(x2 + y2);
      if (closest1 <= COLLISION_CHECK) // 发现有点距离障碍物很近
      {
        return true;
        break;
      }
    }
  }
  return false;
}

void Dynamic_routing::thread_routing(void)
{
  rclcpp::Rate loop_rate(100ms);
  // 类实例化对象
  FrenetOptimalTrajectory fot;
  // 前探距离
  double lon_decision_horizon = 0;

  // -------------------------Frenet采样路径规划参数初始化--------------------------//
  FrenetHyperparameters fot_hp = {
      10.8 / 3.6, // 最大速度 [m/s]，纵向和横向速度的尺量合
      2.0,        // 最大加速度[m/ss]
      1,          // 最大曲率 [1/m]
      2,          // 最大道路宽度 [m]
      -2,         // 最小道路宽度 [m]
      0.5,        // 道路宽度采样间隔 [m]，值越小，轨迹好的越多，但是太小计算效率不行
      0.2,        // 时间采样间隔[s]，值越大生成的轨迹速度越快
      MaxT,       // 最大预测时间 [s]，值越大生成的轨迹距离越远
      MinT,       // 最小预测时间 [s]，值越大生成的轨迹长度越长
      0.2,        // 目标速度采样间隔 [m/s]
      1,          // 目标速度的采样数量
      0.2,        // 目标位置采样间隔 [m/s]
      1,          // 目标位置的采样数量

      // 损失函数权重
      5.0, // Distance from reference path
      5.0, // Target speed
      1.0, // Target acceleration
      1.0, // Jerk
      0.5, // time
      // 总的
      1, // Lateral
      1, // Longitudin
  };

  while (rclcpp::ok())
  {
    if (set_reference == true)
    {
      //--------------------------------------------------生成轨迹--------------------------------------------------//
      if (reference_points.size() > 0)
      {
        // ---------------------------------------------RIO范围的纵向距离确定-----------------------------------------------//
        lon_decision_horizon = accumulated_s[accumulated_s.size() - 1]; // 我们参考线短，直接参考线的长度

        //--------------------------------------------------创建障碍物对象--------------------------------------------------//
        std::vector<const Obstacle *> obstacles; // Apollo是这种类型，不想改里面的源码，所以对外调整类型
        for (size_t i = 0; i < AllObstacle.size(); i++)
        {
          obstacles.emplace_back(&AllObstacle[i]);
        }
        // -----------------------------------------轨迹规划方案选择执行-------------------------------------------//
        // //车没有合适轨迹停下来重新规划的时候， 有些路径规划参数重新初始化
        if (messege2 == true)
        {
          // 有些路径规划参数重新初始化
          ds0 = Config_.default_init_speed; // 初始的纵向速度[m/s]
          init_relative_time = 0;           // 规划起始点的时间
          v_init = ds0;                     // 规划起始点的速度，没有横向速度，直接等于ds0
          x_init = sub_odom_.pose.pose.position.x;
          y_init = sub_odom_.pose.pose.position.y;
        }
        // auto beforeTime = std::chrono::steady_clock::now(); //计时开始

        if (use_what_planner == 1) // frenet采样规划 ， s/t和d/t
        {
          best_frenet_path = nullptr; // 确保已初始化最佳路径
          std::priority_queue<FrenetPath *, std::vector<FrenetPath *>, CostComparator_for_Frenet> frenet_paths;
          FrenetInitialConditions fot_ic = {
              init_lon_state,               // 初始的纵向值[m]
              ds0,                          // 初始的纵向速度[m/s]
              dds0,                         // 初始的纵向加速度[m/ss]
              d0,                           // 初始的横向偏移值 [m]
              dd0,                          // 初始的横向速度 [m/s]
              ddd0,                         // 初始的横向加速度 [m/s^2]
              0.0,                          // 目标横向速度配置
              0.0,                          // 目标横向加速度配置
              Config_.default_cruise_speed, // 目标速度（即纵向的速度保持） [m/s]
              20,                           // 目标位置,就是前探距离，测试3，按理说要变量赋值
              reference_path.first,         // 输入的参考线x坐标数组
              reference_path.second,        // 输入的参考线y坐标数组
          };
          // 计算轨迹，返回通过各种检测的轨迹数
          if (has_stop == false)
          {
            fot.calc_frenet_paths(&fot_ic, &fot_hp, frenet_paths, csp, reference_path.first, reference_path.second);
          }
          else if (has_stop == true)
          {
            fot.calc_frenet_paths_stop(&fot_ic, &fot_hp, frenet_paths, csp, reference_path.first, reference_path.second);
          }
          // 筛选最优轨迹
          while (!frenet_paths.empty())
          {
            auto top = frenet_paths.top();
            frenet_paths.pop();
            if (is_collision(top, COLLISION_CHECK_THRESHOLD) == false) // 通过碰撞检测
            {
              best_frenet_path = top;
              break;
            }
          }
          // 类型转换，确保发布一致性
          best_path = fot.FrenetPath_to_TrajectoryPoint(best_frenet_path);
        }
        else if (use_what_planner == 2) // lattice规划
        {
          // 创建起点参数
          InitialConditions planning_init_point = {
              d0,   // 初始的横向偏移值 [m]
              dd0,  // 初始的横向速度 [m/s]
              ddd0, // 初始的横向加速度 [m/s^2]

              init_lon_state,     // 初始的纵向值[m]
              ds0,                // 初始的纵向速度[m/s]
              dds0,               // 初始的纵向加速度[m/ss]
              init_relative_time, // 规划起始点的时间

              x_init,
              y_init,
              z_init,
              v_init,
              a_init,

              theta_init,
              kappa_init,
              dkappa_init,
          };
          PlanningTarget planning_target(Config_.default_cruise_speed,  accumulated_s.back(), accumulated_s); // 目标
          if (sqrt((sub_odom_.pose.pose.position.x - goal_pose_.position.x) * (sub_odom_.pose.pose.position.x - goal_pose_.position.x) +
                   (sub_odom_.pose.pose.position.y - goal_pose_.position.y) * (sub_odom_.pose.pose.position.y - goal_pose_.position.y)) < 30.0)
          {
            planning_target.set_stop_point();
          }

          best_path = LP.LatticePlan(planning_init_point, planning_target, obstacles, accumulated_s, reference_points,
                                     FLAGS_lateral_optimization, init_relative_time, lon_decision_horizon);
        }
        else
        {
          RCLCPP_WARN(this->get_logger(), "No planning!");
        }

        // auto afterTime = std::chrono::steady_clock::now(); //计时结束
        // double duration_millsecond = std::chrono::duration<double, std::milli>(afterTime - beforeTime).count();
        // std::cout << duration_millsecond << "ms" << std::endl;
        // std::cout << "best_path:" << best_path.size() << "\n";

        // --------------------------------------最优轨迹的逻辑处理--------------------------------------//
        messege2 = false;
        if (best_path.size() == 0) // 没有轨迹数量
        {
          if (messege2 == false) // 只发布一次
          {
            RCLCPP_WARN(this->get_logger(), "vehical can not pass the road!");
            string aa = "2";
            start_dynamic.data = aa.c_str();
            Start_Dynamic->publish(start_dynamic); // 没有轨迹，发送停车信号
            // 发布空轨迹
            traj_points_.poses.clear();
            traj_points_.header.frame_id = Frame_id;
            traj_points_.header.stamp = rclcpp::Clock().now();
            waypoints_vis_pub_->publish(traj_points_);
            waypoint_msgs::msg::WaypointArray local_waypoints;
            local_waypoints.header.frame_id = Frame_id;
            waypoints_pub_->publish(local_waypoints);
            messege1 = false; // 复位
            messege2 = true;  // 复位
          }
        }
        else
        {
          //---------------------------------发布轨迹---------------------------------//
          // 复制给traj_points_，给发布
          traj_points_.poses.clear();
          traj_points_.header.frame_id = Frame_id;
          traj_points_.header.stamp = rclcpp::Clock().now();
          waypoint_msgs::msg::WaypointArray local_waypoints;
          local_waypoints.header.frame_id = Frame_id;
          for (int i = 0; i < best_path.size(); i++)
          {
            geometry_msgs::msg::PoseStamped pose_stamp;
            pose_stamp.header.frame_id = Frame_id;
            pose_stamp.header.stamp = rclcpp::Clock().now();
            pose_stamp.pose.position.x = best_path[i].x;
            pose_stamp.pose.position.y = best_path[i].y;
            pose_stamp.pose.position.z = 0;
            traj_points_.poses.push_back(pose_stamp);
            //
            waypoint_msgs::msg::Waypoint point;
            point.pose.pose.position.x = best_path[i].x;
            point.pose.pose.position.y = best_path[i].y;
            point.twist.twist.linear.x = best_path[i].v;
            local_waypoints.waypoints.push_back(point);
          }
          waypoints_pub_->publish(local_waypoints);
          waypoints_vis_pub_->publish(traj_points_);
          //--------------------------------发布加速度---------------------------------//
          pubLocalPath_a.poses.clear();
          pubLocalPath_a.header.frame_id = Frame_id;
          pubLocalPath_a.header.stamp = rclcpp::Clock().now();
          for (size_t i = 0; i < best_path.size(); i++)
          {
            geometry_msgs::msg::Pose init_pose;
            init_pose.position.x = best_path[i].a;
            pubLocalPath_a.poses.push_back(init_pose);
          }
          local_paths_a->publish(pubLocalPath_a);
          //--------------------------------发布角度---------------------------------//
          pubLocalPath_t.poses.clear();
          pubLocalPath_t.header.frame_id = Frame_id;
          pubLocalPath_t.header.stamp = rclcpp::Clock().now();
          for (size_t i = 0; i < best_path.size(); i++)
          {
            geometry_msgs::msg::Pose init_pose;
            init_pose.position.x = best_path[i].theta;
            pubLocalPath_t.poses.push_back(init_pose);
          }
          local_paths_t->publish(pubLocalPath_t);
          //--------------------------------发布曲率---------------------------------//
          pubLocalPath_k.poses.clear();
          pubLocalPath_k.header.frame_id = Frame_id;
          pubLocalPath_k.header.stamp = rclcpp::Clock().now();
          for (size_t i = 0; i < best_path.size(); i++)
          {
            geometry_msgs::msg::Pose init_pose;
            init_pose.position.x = best_path[i].kappa;
            pubLocalPath_k.poses.push_back(init_pose);
          }
          local_paths_k->publish(pubLocalPath_k);

          //--------------------------------发布局部轨迹生成成功标志---------------------------------//
          if (messege1 == false) // 只发布一次,最开始生成局部轨迹的时候发
          {
            sleep(0.3); // 等会再开车，延时1秒
            string aa = "1";
            start_dynamic.data = aa.c_str();
            Start_Dynamic->publish(start_dynamic); // 发送局部轨迹生成信号给全局路径
            messege1 = true;
          }
          //--------------------------------更新轨迹，根据位置更新---------------------------------//
          ego_is_running = true;
          int update_pos;
          if (use_what_planner == 3)
            update_pos = 15;
          else if (use_what_planner == 5)
            update_pos = 3;
          else
            update_pos = 8;
          // use_what_planner != 4是因为混合A*不用更新，直接起点到终点规划（全局规划）
          if (is_update_dynamic(traj_points_, sub_odom_, update_pos + 3) == true && use_what_planner != 4)
          {
            init_lon_state = best_path[update_pos].s;
            ds0 = best_path[update_pos].s_d;
            dds0 = best_path[update_pos].s_dd;
            d0 = best_path[update_pos].d;
            dd0 = best_path[update_pos].d_d;
            ddd0 = best_path[update_pos].d_dd;

            init_relative_time = 0; // best_path[update_pos].relative_time，动态障碍物的起始时间跟这个保持一致
            x_init = best_path[update_pos].x;
            y_init = best_path[update_pos].y;
            z_init = 0;
            v_init = best_path[update_pos].v;
            a_init = best_path[update_pos].a;

            theta_init = best_path[update_pos].theta;
            kappa_init = best_path[update_pos].kappa;
            dkappa_init = best_path[update_pos].dkappa;
          }
        }
        // 到达终点判断
        double dis = sqrt((sub_odom_.pose.pose.position.x - goal_pose_.position.x) * (sub_odom_.pose.pose.position.x - goal_pose_.position.x) +
                          (sub_odom_.pose.pose.position.y - goal_pose_.position.y) * (sub_odom_.pose.pose.position.y - goal_pose_.position.y));
        // RCLCPP_WARN(this->get_logger(), "dis: %2f", dis);
        if (dis < goal_distanse)
        {
          ego_is_running = false;
          set_reference = false;
        }
      }
      else
      {
        RCLCPP_WARN(this->get_logger(), "Other reference lines are empty and cannot plan!");
      }
    }

    loop_rate.sleep();
  }
}

void another_executor()
{
  rclcpp::executors::SingleThreadedExecutor executor_;
  auto obstacle_test_node_ = std::make_shared<ObstacleTest>("obstacle_test_node", obstacle_test_path);
  executor_.add_node(obstacle_test_node_);

  auto getobstacle_node_ = std::make_shared<GetObstacle>("getobstacle_node", carla_simulation, role_name);
  executor_.add_node(getobstacle_node_);
  executor_.spin();
}

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto dynamic_node_ = std::make_shared<Dynamic_routing>();
  rclcpp::executors::SingleThreadedExecutor executor_;
  RCLCPP_WARN(dynamic_node_->get_logger(), "Initializa DynamicRouting Node~");
  std::thread another(another_executor);

  executor_.add_node(dynamic_node_);
  executor_.spin();
  another.join();

  rclcpp::spin(dynamic_node_);
  rclcpp::shutdown();
  return 0;
}