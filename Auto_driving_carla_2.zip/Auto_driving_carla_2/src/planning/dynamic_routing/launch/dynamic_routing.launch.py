import os
import launch
from launch import LaunchDescription
import launch_ros.actions
from ament_index_python.packages import get_package_share_directory
from nav2_common.launch import RewrittenYaml


def generate_launch_description():
    obstacle_test_path = os.path.join(get_package_share_directory(
        'dynamic_routing'), 'obstacle_files')

    ld = launch.LaunchDescription([
        launch.actions.DeclareLaunchArgument(
            name='is_planner',
            default_value='1'
        ),
        launch.actions.DeclareLaunchArgument(
            name='is_lateral_optimization',
            default_value='false'
        ),
        launch.actions.DeclareLaunchArgument(
            name='is_carla_simulation',
            default_value='false'
        ),
        launch.actions.DeclareLaunchArgument(
            name='ego_vehicle_name',
            default_value='ego_vehicle'
        ),
        launch.actions.DeclareLaunchArgument(
            name='is_goal',
            default_value='0.2'
        ),
        #
        launch.actions.DeclareLaunchArgument(
            name='COLLISION_CHECK_THRESHOLD',
            default_value='2.0'
        ),
        launch.actions.DeclareLaunchArgument(
            name='MaxT',
            default_value='11.0'
        ),
        launch.actions.DeclareLaunchArgument(
            name='MinT',
            default_value='9.0'
        ),
        launch.actions.DeclareLaunchArgument(
            name='obstacle_test_path',
            default_value=obstacle_test_path
        )
    ])

    #
    start_dynamic_routing_cmd = launch_ros.actions.Node(
        package='dynamic_routing',
        node_executable='dynamic_routing_node',
        output='screen',
        parameters=[{
                        'use_what_planner': launch.substitutions.LaunchConfiguration('is_planner'),
                        'use_lateral_optimization': launch.substitutions.LaunchConfiguration('is_lateral_optimization'),
                        'carla_simulation': launch.substitutions.LaunchConfiguration('is_carla_simulation'),
                        'role_name': launch.substitutions.LaunchConfiguration('ego_vehicle_name'),
                        'goal_distanse': launch.substitutions.LaunchConfiguration('is_goal'),
                        'COLLISION_CHECK_THRESHOLD': launch.substitutions.LaunchConfiguration('COLLISION_CHECK_THRESHOLD'),
                        'MaxT': launch.substitutions.LaunchConfiguration('MaxT'),
                        'MinT': launch.substitutions.LaunchConfiguration('MinT'),
                        'obstacle_test_path': launch.substitutions.LaunchConfiguration('obstacle_test_path'),
        }]
    )

    map_file = os.path.join(get_package_share_directory('dynamic_routing'), 'maps', 'map.yaml')
    map_server = launch_ros.actions.Node(
        package='nav2_map_server',
        node_executable='map_server',
        name='map_server',
        output='screen',
        parameters=[
            {'use_sim_time': True}, 
            {'yaml_filename': map_file},
            {"topic_name": "map_empty" }
        ]
    )
    ld.add_action(start_dynamic_routing_cmd)
    ld.add_action(map_server)
    return ld


if __name__ == '__main__':
    generate_launch_description()
