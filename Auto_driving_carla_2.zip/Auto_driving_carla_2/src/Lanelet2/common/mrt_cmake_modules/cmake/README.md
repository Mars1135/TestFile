# Contributing cmake find scripts

Please make sure to format your `FindMyNewLibrary.cmake` files with `cmake-format` from the [cmakelang python package](https://pypi.org/project/cmakelang/), before creating merge requests.
