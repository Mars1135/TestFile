^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package lanelet2_matching
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.1 (2023-05-10)
------------------

1.2.0 (2023-01-30)
------------------
* Add CI using GitHub Actions (`#256 <https://github.com/fzi-forschungszentrum-informatik/Lanelet2/issues/256>`_)
* Move matching integration test to examples
* Name integration tests correctly and remove utils tests
* Add unittests with simple map
* Rename integration test file
* Remove changelog and license
* Switch to lanelet2.matching in python
* Fix package.xml
* Move python bindings of lanelet2_matching to lanelet2_python
* Integrate into lanelet2
* Contributors: Fabian Poggenhans, Maximilian Naumann, Nico Neumann, Fabian Immel

1.1.1 (2020-09-14)
------------------

1.0.1 (2020-03-24)
------------------

1.0.0 (2020-03-03)
------------------
