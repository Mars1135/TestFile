# ros2-carla联合仿真的工程版本说明

## 学习建议

先学一下ubuntu的使用，ros1和ros2的知识，再来使用工程会更好，因为每个电脑的系统配置有差别，不能保证每个人都顺利成章地快速跑起代码，博客也已经尽可能多的记录了可能会遇到的报错问题和解决方法。python环境分为ubuntu18.04和20.04的使用说明，自己对号入座。

## ubuntu18.04的使用

### python版本说明

ubuntu18.04的ros2不能像ros1一样使用python2.7，必须是3.7！！！

**选择一：系统安装的python3.7（ubuntu18.04不适用，因为ros2只到Python3.6）**

我是直接

```
sudo apt -y install python3.X-dev
```

也可以参考其他教程

https://blog.csdn.net/xiangfengl/article/details/124161183

由于存在python3的软连接指向系统默认python3.6，因此建立python3.7指向新安装python版本即可

https://blog.csdn.net/l1353915595/article/details/128183330

**ubuntu18.04这里涉及python2.7和python3.7版本的互切**：

python2.7 -> python3.7

```
先执行：
sudo update-alternatives --config python
选择编号切换为3.6
再执行
sudo update-alternatives --config python3
选择编号切换为3.7
```

python3.7 -> python2.7

```
直接执行：
sudo update-alternatives --config python
选择编号切换为2.7
```



**选择二：conda安装的python3.7（有个很大的bug，这里先提解决方法），ubuntu18.04就选这个方案**

Could not import 'rosidl_typesupport_c' for package 'carla_msgs'

解决这个Bug花了一下午，看到有人说是conda的问题，但是ubuntu18.04不用conda又不行，因为系统安装的会出现与ros2要求Python3.6不匹配的问题。

绕来哦绕去，最终解决方法如下：

（1）在.bashrc里面添加：

```
export PATH="<copy here>""/opt/anaconda3/envs/autoware/bin"
export PATH="/opt/ros/eloquent/bin:/opt/anaconda3/condabin:/home/xx/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin"
```

注意，这里的anaconda3路径，ros版本路径，和/home/xx/.local/bin路径，要改称自己的。

（2）然后重启终端，退出conda环境，用系统默认的python2.7环境（针对ubuntu18.04），再编译colcon build

（3）编译完成后，打开新的终端，进入conda的python3.7虚拟环境，去执行ros2 launch。

以上操作只需要在第一次编译的时候执行，也就是后面编译直接在conda里面编译。但是，如果删除编译的文件，就又得按照以上步骤吧（还没测试）。



编译前在python3.7环境里面安装一下：

```
pip install numpy==1.19.5
pip install empy==3.3.2
pip install lark
pip install transforms3d
pip install pygame==1.9.3
pip install networkx (这个需要在系统默认的python3.6安装)
```



## ubuntu20.04的使用

### python版本说明

**选择conda安装的python3.7**

编译前在python3.7环境里面安装一下：

```
pip install numpy==1.19.5
pip install empy==3.3.2
pip install lark
pip install transforms3d
pip install pygame==1.9.3
pip install networkx (这个需要在系统默认的python3.6安装)
```

这里记得，编译前，把文件夹里面的Lanelet包全部删除，然后

```
sudo apt install ros-foxy-lanelet2
```

再进行安装，不然会报如下错误：

![在这里插入图片描述](https://img-blog.csdnimg.cn/direct/ade9c34790de4288aeacbd6479de78d9.png)

工程带的Lanelet源码包只适合ubuntu18.04。

### 环境配置

修改代码路径，改为自己的绝对路径：

1.yaml路径：src/planning/dynamic_routing/src/common/Config.cpp

![在这里插入图片描述](https://img-blog.csdnimg.cn/direct/85026a8edd4048a38d3f0e98894fc94d.png)

2.rviz路径：src/planning/global_routing/launch/global_routing_with_rviz.launch.py

![在这里插入图片描述](https://img-blog.csdnimg.cn/direct/b507c6f210f3468fab8d29608d29e808.png)

3.town路径：src/map_visualizer/src/osmVisualizer.cpp

![在这里插入图片描述](https://img-blog.csdnimg.cn/direct/7ada659b77044b4ea187da542e60a724.png)





其他依赖库，包括osqp等，可以按照ros1的环境搭建步骤：https://blog.csdn.net/weixin_39735688/article/details/131876243

唯一要注意的是，里面可能涉及的一些ros的库，需要换成ros2版本的sudo apt-get安装。



### ros2-carla0.9.13联合仿真配置

.bashrc配置：

```
export PYTHONPATH=$PYTHONPATH:/home/xx/carla-0.9.13/PythonAPI/carla/dist/carla-0.9.13-py3.7-linux-x86_64.egg
export PYTHONPATH=$PYTHONPATH:/home/xx/carla-0.9.13/PythonAPI/carla/dist/carla-0.9.13-py3.7-linux-x86_64.egg:/home/xx/carla-0.9.13/PythonAPI/carla
```

重启终端，运行：

```
source install/setup.bash
```

启动carla-ros联合仿真节点：

```
ros2 launch src/planning/ros-bridge/carla_ros_bridge/launch/carla_ros_bridge_with_ego_vehicle.launch.py
```

启动规划节点（如果有崩掉则重启）：

```
ros2 launch src/planning/global_routing/launch/global_routing.launch.py
```



这里要注意，我使用的是ubuntu18.04的eloquent版本，所以launch.py里面的节点写法有区别，如果你们是其他版本，应该是需要修改的。一般来说，就是将所运行的.launch.py文件中的“executable=xxxx”改为“node_executable=xxxx”，或者“node_executable=xxxx”改为“executable=xxxx”，还有node_name和name互改。

可以先了解ros2的基本知识，网上有很多教程。



## 该版本存在的不足

1.只能规划一次，到达终点如果要再重新规划，需要重启所有节点。

2.carla仿真时，Town03有滑坡，所以如果车辆初始化在滑坡上，会导致车自己滑动，无法规划，可以考虑换其他Town，或者找平路。



























